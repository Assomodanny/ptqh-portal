export type Course = {
  /** Stable slug — will map to a backend course record later. */
  id: string;
  arabicTitle: string;
  englishTitle: string;
  description: string;
};

/**
 * Curriculum modules. This list is data-driven: adding a course here renders a
 * new card without touching layout code. It will be swapped for backend data
 * in a later stage — keep the `Course` shape stable.
 */
export const curriculum: Course[] = [
  {
    id: "nahwu",
    arabicTitle: "النحو",
    englishTitle: "Nahwu",
    description:
      "Arabic grammar and sentence structure — the rules of ʿirāb and the syntax that carries meaning in the Qur'anic text.",
  },
  {
    id: "sarf",
    arabicTitle: "الصرف",
    englishTitle: "Sarf",
    description:
      "Arabic morphology and word formation — verb patterns and derivations that reveal the precision of Qur'anic vocabulary.",
  },
  {
    id: "tajweed",
    arabicTitle: "التجويد والقراءة القرآنية",
    englishTitle: "Tajweed & Qur'anic Recitation",
    description:
      "The rules of articulation, elongation, and pause, applied through supervised recitation before a teacher.",
  },
  {
    id: "hadith",
    arabicTitle: "الحديث",
    englishTitle: "Hadith",
    description:
      "Prophetic traditions — their texts, transmission, and the etiquette of studying and narrating them.",
  },
  {
    id: "hifz",
    arabicTitle: "الحفظ",
    englishTitle: "Hifz",
    description:
      "Qur'an memorisation with a structured schedule of new portions, daily review, and periodic consolidation.",
  },
  {
    id: "tafsir",
    arabicTitle: "التفسير",
    englishTitle: "Tafsir",
    description:
      "Qur'anic interpretation — reading verses in the light of established scholarship, context, and related evidence.",
  },
  {
    id: "as-sarim-al-battar",
    arabicTitle: "الصارم البتار",
    englishTitle: "As-Sarim Al-Battar",
    description:
      "A dedicated module treating the classical text as a distinct course within the programme.",
  },
];
