/**
 * Auth integration point — backed by the school's existing Supabase project.
 * All auth logic stays isolated in this module.
 */
import { useEffect, useState } from "react";

import { supabase } from "./supabase";

export type User = {
  id: string;
  email: string;
} | null;

export type AuthState = {
  user: User;
  isLoading: boolean;
};

export function useAuth(): AuthState {
  const [state, setState] = useState<AuthState>({ user: null, isLoading: true });

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((_event, session) => {
      setState({
        user: session?.user ? { id: session.user.id, email: session.user.email ?? "" } : null,
        isLoading: false,
      });
    });

    void supabase.auth.getUser().then(({ data }) => {
      setState({
        user: data.user ? { id: data.user.id, email: data.user.email ?? "" } : null,
        isLoading: false,
      });
    });

    return () => sub.subscription.unsubscribe();
  }, []);

  return state;
}

export async function signInWithEmail(
  email: string,
  password: string,
): Promise<{ error?: string }> {
  const { error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) return { error: error.message };
  return {};
}

export async function signOut(): Promise<void> {
  await supabase.auth.signOut();
}
