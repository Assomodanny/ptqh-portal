/**
 * Read-only portal queries against the school's EXISTING Supabase schema.
 * No schema changes are made here — table/column names match the provided schema.
 */
import { supabase } from "./supabase";

export type RoleName = "admin" | "teacher" | "student";

export type Profile = {
  id: string;
  full_name: string | null;
  email: string | null;
  phone: string | null;
  avatar_url: string | null;
  is_active: boolean | null;
};

export type TeacherRow = {
  id: string;
  profile_id: string;
  employee_id: string | null;
  qualification: string | null;
  specialization: string | null;
  status: string | null;
};

export type StudentRow = {
  id: string;
  profile_id: string;
  student_id: string | null;
  class_name: string | null;
  admission_date: string | null;
  date_of_birth: string | null;
  gender: string | null;
  status: string | null;
};

export type SubjectRow = {
  id: string;
  name: string | null;
  code: string | null;
  description: string | null;
  is_active: boolean | null;
};

export type EnrollmentWithSubject = {
  id: string;
  enrolled_at: string | null;
  status: string | null;
  subjects: SubjectRow | null;
};

export type LiveClass = {
  id: string;
  subject: string | null;
  day_of_week: string | number | null;
  start_time: string | null;
  end_time: string | null;
  platform: string | null;
  join_url: string | null;
  is_active: boolean | null;
};

/** Resolve the signed-in user's role via user_roles → roles.name. */
export async function fetchUserRole(userId: string): Promise<RoleName | null> {
  const { data, error } = await supabase
    .from("user_roles")
    .select("roles(name)")
    .eq("user_id", userId);
  if (error) throw new Error(error.message);

  const names = (data ?? [])
    .flatMap((row: { roles: { name: string | null } | { name: string | null }[] | null }) =>
      Array.isArray(row.roles) ? row.roles : row.roles ? [row.roles] : [],
    )
    .map((r) => (r.name ?? "").toLowerCase());

  for (const candidate of ["admin", "teacher", "student"] as const) {
    if (names.includes(candidate)) return candidate;
  }
  return null;
}

export const roleHome: Record<RoleName, "/admin" | "/teacher" | "/student"> = {
  admin: "/admin",
  teacher: "/teacher",
  student: "/student",
};

/** profiles.id is the shared identity id (matches auth.users.id). */
export async function fetchProfile(userId: string): Promise<Profile | null> {
  const { data, error } = await supabase
    .from("profiles")
    .select("id, full_name, email, phone, avatar_url, is_active")
    .eq("id", userId)
    .maybeSingle();
  if (error) throw new Error(error.message);
  return (data as Profile | null) ?? null;
}

export async function fetchAdminCounts(): Promise<{
  students: number;
  teachers: number;
  subjects: number;
}> {
  const [students, teachers, subjects] = await Promise.all([
    supabase.from("students").select("id", { count: "exact", head: true }),
    supabase.from("teachers").select("id", { count: "exact", head: true }),
    supabase.from("subjects").select("id", { count: "exact", head: true }),
  ]);
  const firstError = students.error ?? teachers.error ?? subjects.error;
  if (firstError) throw new Error(firstError.message);
  return {
    students: students.count ?? 0,
    teachers: teachers.count ?? 0,
    subjects: subjects.count ?? 0,
  };
}

export async function fetchTeacherByProfile(profileId: string): Promise<TeacherRow | null> {
  const { data, error } = await supabase
    .from("teachers")
    .select("id, profile_id, employee_id, qualification, specialization, status")
    .eq("profile_id", profileId)
    .maybeSingle();
  if (error) throw new Error(error.message);
  return (data as TeacherRow | null) ?? null;
}

export async function fetchStudentByProfile(profileId: string): Promise<StudentRow | null> {
  const { data, error } = await supabase
    .from("students")
    .select(
      "id, profile_id, student_id, class_name, admission_date, date_of_birth, gender, status",
    )
    .eq("profile_id", profileId)
    .maybeSingle();
  if (error) throw new Error(error.message);
  return (data as StudentRow | null) ?? null;
}

export async function fetchEnrollments(studentRowId: string): Promise<EnrollmentWithSubject[]> {
  const { data, error } = await supabase
    .from("enrollments")
    .select("id, enrolled_at, status, subjects(id, name, code, description, is_active)")
    .eq("student_id", studentRowId);
  if (error) throw new Error(error.message);
  return ((data ?? []) as unknown as EnrollmentWithSubject[]).map((row) => ({
    ...row,
    subjects: Array.isArray(row.subjects) ? (row.subjects[0] ?? null) : row.subjects,
  }));
}

export async function fetchLiveClasses(): Promise<LiveClass[]> {
  const { data, error } = await supabase
    .from("live_classes")
    .select("id, subject, day_of_week, start_time, end_time, platform, join_url, is_active")
    .eq("is_active", true);
  if (error) throw new Error(error.message);
  return (data ?? []) as LiveClass[];
}

const dayNames = [
  "Sunday",
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
];

/** "Every Wednesday" / "Schedule pending" for null values. */
export function formatDay(day: LiveClass["day_of_week"]): string {
  if (day === null || day === undefined || day === "") return "Schedule pending";
  if (typeof day === "number") return dayNames[day] ? `Every ${dayNames[day]}` : "Schedule pending";
  const numeric = Number(day);
  if (!Number.isNaN(numeric) && dayNames[numeric]) return `Every ${dayNames[numeric]}`;
  const label = day.charAt(0).toUpperCase() + day.slice(1).toLowerCase();
  return `Every ${label}`;
}

function formatTime(value: string): string {
  const [h, m] = value.split(":");
  const hour = Number(h);
  if (Number.isNaN(hour)) return value;
  const suffix = hour >= 12 ? "PM" : "AM";
  const hour12 = hour % 12 === 0 ? 12 : hour % 12;
  return `${hour12}:${m ?? "00"} ${suffix}`;
}

export function formatTimeRange(start: string | null, end: string | null): string {
  if (!start) return "Schedule pending";
  return end ? `${formatTime(start)} – ${formatTime(end)}` : formatTime(start);
}

export type StudentWithProfile = StudentRow & { profiles: Profile | null };
export type TeacherWithProfile = TeacherRow & { profiles: Profile | null };

function firstOrNull<T>(value: T | T[] | null): T | null {
  return Array.isArray(value) ? (value[0] ?? null) : value;
}

export async function fetchStudents(): Promise<StudentWithProfile[]> {
  const { data, error } = await supabase
    .from("students")
    .select(
      "id, profile_id, student_id, class_name, admission_date, date_of_birth, gender, status, profiles(id, full_name, email, phone, avatar_url, is_active)",
    );
  if (error) throw new Error(error.message);
  return ((data ?? []) as unknown as StudentWithProfile[]).map((row) => ({
    ...row,
    profiles: firstOrNull(row.profiles),
  }));
}

export async function fetchTeachers(): Promise<TeacherWithProfile[]> {
  const { data, error } = await supabase
    .from("teachers")
    .select(
      "id, profile_id, employee_id, qualification, specialization, status, profiles(id, full_name, email, phone, avatar_url, is_active)",
    );
  if (error) throw new Error(error.message);
  return ((data ?? []) as unknown as TeacherWithProfile[]).map((row) => ({
    ...row,
    profiles: firstOrNull(row.profiles),
  }));
}

export type LiveClassInput = {
  subject: string | null;
  day_of_week: string | null;
  start_time: string | null;
  end_time: string | null;
  platform: string | null;
  join_url: string | null;
};

/** Admin-only write (enforced by the existing RLS policy on live_classes). */
export async function createLiveClass(input: LiveClassInput): Promise<void> {
  const { error } = await supabase.from("live_classes").insert({ ...input, is_active: true });
  if (error) throw new Error(error.message);
}

export async function updateLiveClass(id: string, input: Partial<LiveClassInput>): Promise<void> {
  const { error } = await supabase.from("live_classes").update(input).eq("id", id);
  if (error) throw new Error(error.message);
}

export async function deleteLiveClass(id: string): Promise<void> {
  const { error } = await supabase.from("live_classes").delete().eq("id", id);
  if (error) throw new Error(error.message);
}

/** "google_meet" → "Google Meet". */
export function formatPlatform(platform: string | null): string {
  if (!platform) return "Platform to be confirmed";
  return platform
    .split(/[_\s-]+/)
    .filter(Boolean)
    .map((word) => (word.toLowerCase() === "whatsapp" ? "WhatsApp" : word.charAt(0).toUpperCase() + word.slice(1)))
    .join(" ");
}

/* ---------------------------------------------------------------------------
 * Payments (existing `payments` table — no schema changes)
 * Columns: id, student_id, subject_id, month (date, 1st of month), amount_due,
 * amount_paid, payment_date, is_paid, grace_period_active, receipt_reference.
 * Some rows have student_id = null; those are matched by the tagged reference
 * in receipt_reference, format "[STUDENT_ID] ...".
 * ------------------------------------------------------------------------- */

export type PaymentRow = {
  id: string;
  student_id: string | null;
  subject_id: string | null;
  month: string | null;
  amount_due: number | null;
  amount_paid: number | null;
  payment_date: string | null;
  is_paid: boolean | null;
  grace_period_active: boolean | null;
  receipt_reference: string | null;
  created_at: string | null;
};

const paymentColumns =
  "id, student_id, subject_id, month, amount_due, amount_paid, payment_date, is_paid, grace_period_active, receipt_reference, created_at";

/** First day of the given month as an ISO date string (YYYY-MM-01). */
export function monthStart(date = new Date()): string {
  const year = date.getFullYear();
  const month = `${date.getMonth() + 1}`.padStart(2, "0");
  return `${year}-${month}-01`;
}

/** The tag a workaround row carries, e.g. "STU001" → "[STU001]". */
export function referenceTag(studentCode: string): string {
  return `[${studentCode}]`;
}

/**
 * Current-month payments for one student: rows linked by student_id, plus
 * untagged-workaround rows whose receipt_reference starts with [STUDENT_ID].
 */
export async function fetchStudentPayments(
  studentRowId: string,
  studentCode: string | null,
  month = monthStart(),
): Promise<PaymentRow[]> {
  const byId = supabase
    .from("payments")
    .select(paymentColumns)
    .eq("month", month)
    .eq("student_id", studentRowId);

  const byReference = studentCode
    ? supabase
        .from("payments")
        .select(paymentColumns)
        .eq("month", month)
        .is("student_id", null)
        .ilike("receipt_reference", `${referenceTag(studentCode)}%`)
    : null;

  const [linked, tagged] = await Promise.all([byId, byReference ?? Promise.resolve(null)]);
  if (linked.error) throw new Error(linked.error.message);
  if (tagged?.error) throw new Error(tagged.error.message);

  const rows = [...((linked.data ?? []) as PaymentRow[]), ...((tagged?.data ?? []) as PaymentRow[])];
  const seen = new Set<string>();
  return rows.filter((row) => (seen.has(row.id) ? false : (seen.add(row.id), true)));
}

export type PaymentStatus = {
  /** Unpaid rows for the current month. */
  unpaid: PaymentRow[];
  /** Sum of amount_due − amount_paid across unpaid rows. */
  amountOwed: number;
  /** True while today is on or before the 3rd (1st + 2 grace days). */
  withinGrace: boolean;
  /** True when the dashboard should be blocked. */
  blocked: boolean;
};

/**
 * Gating rule: block only when an unpaid row exists for the current month AND
 * the 2-day grace period after the 1st has passed AND no row still carries
 * grace_period_active. Students with no payment record are never blocked.
 */
export function evaluatePaymentStatus(rows: PaymentRow[], today = new Date()): PaymentStatus {
  const unpaid = rows.filter((row) => row.is_paid !== true);
  const amountOwed = unpaid.reduce(
    (total, row) => total + Math.max((row.amount_due ?? 0) - (row.amount_paid ?? 0), 0),
    0,
  );
  const withinGrace =
    today.getDate() <= 3 || unpaid.some((row) => row.grace_period_active === true);
  return { unpaid, amountOwed, withinGrace, blocked: unpaid.length > 0 && !withinGrace };
}

export function formatNaira(amount: number): string {
  return `₦${amount.toLocaleString("en-NG")}`;
}

export function formatMonth(month: string | null): string {
  if (!month) return "This month";
  const date = new Date(`${month}T00:00:00`);
  if (Number.isNaN(date.getTime())) return month;
  return date.toLocaleDateString("en-NG", { month: "long", year: "numeric" });
}

export type PaymentWithStudent = PaymentRow & { students: (StudentRow & { profiles: Profile | null }) | null };

/** All payments for a month, newest first — admin view. */
export async function fetchPayments(month = monthStart()): Promise<PaymentRow[]> {
  const { data, error } = await supabase
    .from("payments")
    .select(paymentColumns)
    .eq("month", month)
    .order("created_at", { ascending: false });
  if (error) throw new Error(error.message);
  return (data ?? []) as PaymentRow[];
}

/** Admin-only write (enforced by the existing RLS policy on payments). */
export async function setPaymentPaid(row: PaymentRow, isPaid: boolean): Promise<void> {
  const { error } = await supabase
    .from("payments")
    .update(
      isPaid
        ? {
            is_paid: true,
            amount_paid: row.amount_due ?? row.amount_paid ?? 0,
            payment_date: new Date().toISOString(),
          }
        : { is_paid: false, amount_paid: 0, payment_date: null },
    )
    .eq("id", row.id);
  if (error) throw new Error(error.message);
}

/** "[STU001] MNP-TRF-…" → "STU001" */
export function referenceStudentCode(reference: string | null): string | null {
  const match = reference?.match(/^\s*\[([^\]]+)\]/);
  return match?.[1]?.trim() ?? null;
}
