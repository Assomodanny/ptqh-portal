/**
 * Live quiz queries against the school's EXISTING Supabase quiz tables.
 * No schema changes: quizzes, quiz_questions, quiz_sessions, quiz_participants, quiz_answers.
 */
import { supabase } from "./supabase";

export type Quiz = {
  id: string;
  subject: string | null;
  title: string | null;
  description: string | null;
  created_by: string | null;
  created_at: string | null;
};

export type QuizQuestion = {
  id: string;
  quiz_id: string;
  question_text: string | null;
  option_a: string | null;
  option_b: string | null;
  option_c: string | null;
  option_d: string | null;
  correct_answer: string | null;
  timer_seconds: number | null;
  question_order: number | null;
};

export type QuizSession = {
  id: string;
  quiz_id: string;
  pin_code: string | null;
  status: string | null;
  current_question_index: number | null;
  started_at: string | null;
  created_at: string | null;
};

export type QuizParticipant = {
  id: string;
  session_id: string;
  student_name: string | null;
  score: number | null;
  joined_at: string | null;
};

export type QuizAnswer = {
  id: string;
  session_id: string;
  participant_id: string;
  question_id: string;
  selected_answer: string | null;
  is_correct: boolean | null;
  answered_at: string | null;
};

export type QuizWithCount = Quiz & { questionCount: number };

export const POINTS_PER_CORRECT = 10;
export const optionKeys = ["a", "b", "c", "d"] as const;
export type OptionKey = (typeof optionKeys)[number];

export function optionText(question: QuizQuestion, key: OptionKey): string | null {
  return question[`option_${key}` as const] ?? null;
}

/** correct_answer may be stored as "a"/"A"/"option_a" — normalise to a bare key. */
export function normaliseAnswer(value: string | null): OptionKey | null {
  if (!value) return null;
  const cleaned = value.trim().toLowerCase().replace(/^option[_\s-]*/, "");
  return (optionKeys as readonly string[]).includes(cleaned) ? (cleaned as OptionKey) : null;
}

export async function fetchQuizzes(): Promise<QuizWithCount[]> {
  const [quizzes, questions] = await Promise.all([
    supabase
      .from("quizzes")
      .select("id, subject, title, description, created_by, created_at")
      .order("created_at", { ascending: false }),
    supabase.from("quiz_questions").select("id, quiz_id"),
  ]);
  const firstError = quizzes.error ?? questions.error;
  if (firstError) throw new Error(firstError.message);

  const counts = new Map<string, number>();
  for (const row of (questions.data ?? []) as { quiz_id: string }[]) {
    counts.set(row.quiz_id, (counts.get(row.quiz_id) ?? 0) + 1);
  }
  return ((quizzes.data ?? []) as Quiz[]).map((quiz) => ({
    ...quiz,
    questionCount: counts.get(quiz.id) ?? 0,
  }));
}

export async function fetchQuizQuestions(quizId: string): Promise<QuizQuestion[]> {
  const { data, error } = await supabase
    .from("quiz_questions")
    .select(
      "id, quiz_id, question_text, option_a, option_b, option_c, option_d, correct_answer, timer_seconds, question_order",
    )
    .eq("quiz_id", quizId)
    .order("question_order", { ascending: true });
  if (error) throw new Error(error.message);
  return (data ?? []) as QuizQuestion[];
}

export async function fetchSession(sessionId: string): Promise<QuizSession | null> {
  const { data, error } = await supabase
    .from("quiz_sessions")
    .select("id, quiz_id, pin_code, status, current_question_index, started_at, created_at")
    .eq("id", sessionId)
    .maybeSingle();
  if (error) throw new Error(error.message);
  return (data as QuizSession | null) ?? null;
}

export async function fetchSessionByPin(pin: string): Promise<QuizSession | null> {
  const { data, error } = await supabase
    .from("quiz_sessions")
    .select("id, quiz_id, pin_code, status, current_question_index, started_at, created_at")
    .eq("pin_code", pin)
    .neq("status", "ended")
    .order("created_at", { ascending: false })
    .limit(1);
  if (error) throw new Error(error.message);
  return ((data ?? [])[0] as QuizSession | undefined) ?? null;
}

export async function fetchParticipants(sessionId: string): Promise<QuizParticipant[]> {
  const { data, error } = await supabase
    .from("quiz_participants")
    .select("id, session_id, student_name, score, joined_at")
    .eq("session_id", sessionId)
    .order("score", { ascending: false });
  if (error) throw new Error(error.message);
  return (data ?? []) as QuizParticipant[];
}

export async function fetchSessionAnswers(sessionId: string): Promise<QuizAnswer[]> {
  const { data, error } = await supabase
    .from("quiz_answers")
    .select("id, session_id, participant_id, question_id, selected_answer, is_correct, answered_at")
    .eq("session_id", sessionId);
  if (error) throw new Error(error.message);
  return (data ?? []) as QuizAnswer[];
}

function generatePin(): string {
  return String(Math.floor(100000 + Math.random() * 900000));
}

/** Host action — creates a waiting session with a fresh 6-digit PIN. */
export async function createSession(quizId: string): Promise<QuizSession> {
  let lastError: string | null = null;
  for (let attempt = 0; attempt < 5; attempt += 1) {
    const pin = generatePin();
    const { data, error } = await supabase
      .from("quiz_sessions")
      .insert({
        quiz_id: quizId,
        pin_code: pin,
        status: "waiting",
        current_question_index: 0,
      })
      .select("id, quiz_id, pin_code, status, current_question_index, started_at, created_at")
      .single();
    if (!error && data) return data as QuizSession;
    lastError = error?.message ?? "Could not create the session.";
    if (!error?.message?.toLowerCase().includes("duplicate")) break;
  }
  throw new Error(lastError ?? "Could not create the session.");
}

export async function startSession(sessionId: string): Promise<void> {
  const { error } = await supabase
    .from("quiz_sessions")
    .update({ status: "active", current_question_index: 0, started_at: new Date().toISOString() })
    .eq("id", sessionId);
  if (error) throw new Error(error.message);
}

export async function setQuestionIndex(sessionId: string, index: number): Promise<void> {
  const { error } = await supabase
    .from("quiz_sessions")
    .update({ status: "active", current_question_index: index })
    .eq("id", sessionId);
  if (error) throw new Error(error.message);
}

export async function endSession(sessionId: string): Promise<void> {
  const { error } = await supabase
    .from("quiz_sessions")
    .update({ status: "ended" })
    .eq("id", sessionId);
  if (error) throw new Error(error.message);
}

export async function joinSession(
  sessionId: string,
  studentName: string,
): Promise<QuizParticipant> {
  const { data, error } = await supabase
    .from("quiz_participants")
    .insert({ session_id: sessionId, student_name: studentName, score: 0 })
    .select("id, session_id, student_name, score, joined_at")
    .single();
  if (error) throw new Error(error.message);
  return data as QuizParticipant;
}

export async function submitAnswer(input: {
  sessionId: string;
  participantId: string;
  question: QuizQuestion;
  selected: OptionKey;
  currentScore: number;
}): Promise<{ isCorrect: boolean }> {
  const correct = normaliseAnswer(input.question.correct_answer);
  const isCorrect = correct !== null && correct === input.selected;

  const { error } = await supabase.from("quiz_answers").insert({
    session_id: input.sessionId,
    participant_id: input.participantId,
    question_id: input.question.id,
    selected_answer: input.selected,
    is_correct: isCorrect,
  });
  if (error) throw new Error(error.message);

  if (isCorrect) {
    const { error: scoreError } = await supabase
      .from("quiz_participants")
      .update({ score: input.currentScore + POINTS_PER_CORRECT })
      .eq("id", input.participantId);
    if (scoreError) throw new Error(scoreError.message);
  }

  return { isCorrect };
}

/**
 * Realtime sync for one session. All postgres_changes listeners are registered
 * BEFORE subscribe() — required by supabase-js.
 */
export function subscribeToSession(
  sessionId: string,
  handlers: {
    onSession?: (session: QuizSession) => void;
    onParticipants?: () => void;
    onAnswers?: () => void;
  },
): () => void {
  const channel = supabase.channel(`quiz-session-${sessionId}`);

  channel.on(
    "postgres_changes",
    { event: "*", schema: "public", table: "quiz_sessions", filter: `id=eq.${sessionId}` },
    (payload) => {
      const row = payload.new as QuizSession | null;
      if (row?.id) handlers.onSession?.(row);
    },
  );

  channel.on(
    "postgres_changes",
    {
      event: "*",
      schema: "public",
      table: "quiz_participants",
      filter: `session_id=eq.${sessionId}`,
    },
    () => handlers.onParticipants?.(),
  );

  channel.on(
    "postgres_changes",
    { event: "*", schema: "public", table: "quiz_answers", filter: `session_id=eq.${sessionId}` },
    () => handlers.onAnswers?.(),
  );

  channel.subscribe();

  return () => {
    void supabase.removeChannel(channel);
  };
}
