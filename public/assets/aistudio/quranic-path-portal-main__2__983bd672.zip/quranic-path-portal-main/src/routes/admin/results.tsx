import { createFileRoute, Link } from "@tanstack/react-router";

import { EmptyState, PortalShell } from "@/components/portal-shell";
import { usePortalRole } from "@/lib/use-portal-role";

export const Route = createFileRoute("/admin/results")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Results — Admin — Path to Qur'anic Understanding" },
      { name: "description", content: "Assessment results overview for the school." },
      { property: "og:title", content: "Results — Admin" },
      { property: "og:description", content: "Assessment results overview for the school." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminResultsPage,
});

function AdminResultsPage() {
  usePortalRole("admin");

  return (
    <PortalShell
      eyebrow="Administration"
      title="Results"
      subtitle="Assessment results recorded for enrolled students."
    >
      <Link
        to="/admin"
        className="text-sm text-muted-foreground underline underline-offset-4 hover:text-amber"
      >
        ← Back to admin dashboard
      </Link>

      <div className="mt-8">
        <EmptyState
          title="Results are not connected yet"
          body="The results tables have not been wired into the portal yet. Once the assessment records are confirmed, monthly results will be listed here per student and subject."
        />
      </div>
    </PortalShell>
  );
}
