import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";

import { EmptyState, PortalShell } from "@/components/portal-shell";
import { fetchTeachers } from "@/lib/portal";
import { usePortalRole } from "@/lib/use-portal-role";

export const Route = createFileRoute("/admin/teachers")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Teachers — Admin — Path to Qur'anic Understanding" },
      { name: "description", content: "Teaching staff, qualifications and specialisations." },
      { property: "og:title", content: "Teachers — Admin" },
      {
        property: "og:description",
        content: "Teaching staff, qualifications and specialisations.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminTeachersPage,
});

function AdminTeachersPage() {
  const { role } = usePortalRole("admin");
  const teachersQuery = useQuery({
    queryKey: ["admin-teachers"],
    queryFn: fetchTeachers,
    enabled: role === "admin",
  });

  const rows = teachersQuery.data ?? [];

  return (
    <PortalShell eyebrow="Administration" title="Teachers" subtitle="All teaching staff on file.">
      <Link
        to="/admin"
        className="text-sm text-muted-foreground underline underline-offset-4 hover:text-amber"
      >
        ← Back to admin dashboard
      </Link>

      <div className="mt-8">
        {teachersQuery.isLoading ? (
          <p className="text-sm text-muted-foreground">Loading teachers…</p>
        ) : teachersQuery.error ? (
          <p className="rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive">
            {(teachersQuery.error as Error).message}
          </p>
        ) : rows.length === 0 ? (
          <EmptyState
            title="No teachers yet"
            body="Teaching staff records will appear here once the administration adds them."
          />
        ) : (
          <div className="grid gap-4 sm:grid-cols-2">
            {rows.map((teacher) => (
              <div
                key={teacher.id}
                className="rounded-xl border border-border bg-card/70 p-6 transition-colors hover:border-amber/50"
              >
                <p className="font-display text-lg font-semibold text-headline">
                  {teacher.profiles?.full_name ?? "Unnamed teacher"}
                </p>
                {teacher.profiles?.email && (
                  <p className="mt-1 text-xs text-muted-foreground">{teacher.profiles.email}</p>
                )}
                <span className="mt-4 block h-px w-full bg-amber/30" aria-hidden="true" />
                <dl className="mt-4 space-y-2 text-sm">
                  <div className="flex justify-between gap-4">
                    <dt className="text-muted-foreground">Employee ID</dt>
                    <dd className="text-foreground">{teacher.employee_id ?? "—"}</dd>
                  </div>
                  <div className="flex justify-between gap-4">
                    <dt className="text-muted-foreground">Specialisation</dt>
                    <dd className="text-foreground">{teacher.specialization ?? "—"}</dd>
                  </div>
                  <div className="flex justify-between gap-4">
                    <dt className="text-muted-foreground">Qualification</dt>
                    <dd className="text-foreground">{teacher.qualification ?? "—"}</dd>
                  </div>
                  <div className="flex justify-between gap-4">
                    <dt className="text-muted-foreground">Status</dt>
                    <dd className="text-amber">{teacher.status ?? "—"}</dd>
                  </div>
                </dl>
              </div>
            ))}
          </div>
        )}
      </div>
    </PortalShell>
  );
}
