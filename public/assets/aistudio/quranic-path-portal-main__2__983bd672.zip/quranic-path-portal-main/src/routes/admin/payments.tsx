import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import { EmptyState, PortalShell, portalGhostButton } from "@/components/portal-shell";
import {
  fetchPayments,
  fetchStudents,
  formatMonth,
  formatNaira,
  monthStart,
  referenceStudentCode,
  setPaymentPaid,
  type PaymentRow,
} from "@/lib/portal";
import { usePortalRole } from "@/lib/use-portal-role";

export const Route = createFileRoute("/admin/payments")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Payments — Admin — Path to Qur'anic Understanding" },
      { name: "description", content: "Mark monthly student fees as paid or unpaid." },
      { property: "og:title", content: "Payments — Admin" },
      { property: "og:description", content: "Mark monthly student fees as paid or unpaid." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminPaymentsPage,
});

function AdminPaymentsPage() {
  const { role } = usePortalRole("admin");
  const queryClient = useQueryClient();
  const [month, setMonth] = useState(() => monthStart().slice(0, 7));
  const monthKey = `${month}-01`;
  const [error, setError] = useState<string | null>(null);

  const paymentsQuery = useQuery({
    queryKey: ["admin-payments", monthKey],
    queryFn: () => fetchPayments(monthKey),
    enabled: role === "admin",
  });

  const studentsQuery = useQuery({
    queryKey: ["admin-students"],
    queryFn: fetchStudents,
    enabled: role === "admin",
  });

  const nameFor = useMemo(() => {
    const byRowId = new Map<string, string>();
    const byCode = new Map<string, string>();
    for (const student of studentsQuery.data ?? []) {
      const label = student.profiles?.full_name ?? student.student_id ?? "Student";
      byRowId.set(student.id, label);
      if (student.student_id) byCode.set(student.student_id, label);
    }
    return (row: PaymentRow) => {
      if (row.student_id && byRowId.has(row.student_id)) return byRowId.get(row.student_id)!;
      const code = referenceStudentCode(row.receipt_reference);
      if (code && byCode.has(code)) return byCode.get(code)!;
      return code ?? "Unmatched record";
    };
  }, [studentsQuery.data]);

  const mutation = useMutation({
    mutationFn: ({ row, isPaid }: { row: PaymentRow; isPaid: boolean }) =>
      setPaymentPaid(row, isPaid),
    onMutate: () => setError(null),
    onError: (mutationError: Error) => setError(mutationError.message),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["admin-payments", monthKey] });
      void queryClient.invalidateQueries({ queryKey: ["student-payments"] });
    },
  });

  const rows = paymentsQuery.data ?? [];

  return (
    <PortalShell
      eyebrow="Administration"
      title="Payments"
      subtitle="Mark a student's monthly fees as paid or unpaid. Unpaid students see a payment due screen after the 2-day grace period."
    >
      <Link
        to="/admin"
        className="text-sm text-muted-foreground underline underline-offset-4 hover:text-amber"
      >
        ← Back to admin dashboard
      </Link>

      <div className="mt-8 flex flex-wrap items-end gap-4">
        <label className="text-sm">
          <span className="block text-xs uppercase tracking-[0.18em] text-muted-foreground">
            Month
          </span>
          <input
            type="month"
            value={month}
            onChange={(event) => setMonth(event.target.value)}
            className="mt-2 h-11 rounded-md border border-border bg-card/70 px-3 text-sm text-foreground"
          />
        </label>
        <p className="text-sm text-muted-foreground">Showing {formatMonth(monthKey)}</p>
      </div>

      {error && (
        <p className="mt-6 rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive">
          {error}
        </p>
      )}

      <div className="mt-8">
        {paymentsQuery.isLoading ? (
          <p className="text-sm text-muted-foreground">Loading payments…</p>
        ) : paymentsQuery.error ? (
          <p className="rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive">
            {(paymentsQuery.error as Error).message}
          </p>
        ) : rows.length === 0 ? (
          <EmptyState
            title="No payment records for this month"
            body="Records added to the payments table for this month will appear here."
          />
        ) : (
          <div className="overflow-x-auto rounded-xl border border-border bg-card/70">
            <table className="w-full min-w-[48rem] text-left text-sm">
              <thead className="border-b border-border text-xs uppercase tracking-[0.16em] text-muted-foreground">
                <tr>
                  <th className="px-4 py-3 font-medium">Student</th>
                  <th className="px-4 py-3 font-medium">Reference</th>
                  <th className="px-4 py-3 font-medium">Due</th>
                  <th className="px-4 py-3 font-medium">Paid</th>
                  <th className="px-4 py-3 font-medium">Status</th>
                  <th className="px-4 py-3 font-medium">Action</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((row) => (
                  <tr key={row.id} className="border-b border-border/50 last:border-0">
                    <td className="px-4 py-3 text-headline">{nameFor(row)}</td>
                    <td className="px-4 py-3 text-muted-foreground">
                      {row.receipt_reference ?? "—"}
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">
                      {formatNaira(row.amount_due ?? 0)}
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">
                      {formatNaira(row.amount_paid ?? 0)}
                    </td>
                    <td className={row.is_paid ? "px-4 py-3 text-amber" : "px-4 py-3 text-destructive"}>
                      {row.is_paid ? "Paid" : "Unpaid"}
                    </td>
                    <td className="px-4 py-3">
                      <button
                        type="button"
                        disabled={mutation.isPending}
                        onClick={() => mutation.mutate({ row, isPaid: !row.is_paid })}
                        className={`${portalGhostButton} h-9 px-4 text-xs disabled:opacity-60`}
                      >
                        {row.is_paid ? "Mark unpaid" : "Mark paid"}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </PortalShell>
  );
}
