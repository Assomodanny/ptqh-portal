import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";

import { signOut, useAuth } from "@/lib/auth";
import { fetchUserRole, roleHome } from "@/lib/portal";

export const Route = createFileRoute("/dashboard")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Dashboard — Path to Qur'anic Understanding" },
      {
        name: "description",
        content:
          "Your Path to Qur'anic Understanding portal dashboard — you'll be taken to the right view for your role.",
      },
      { property: "og:title", content: "Dashboard — Path to Qur'anic Understanding" },
      {
        property: "og:description",
        content: "Your Path to Qur'anic Understanding portal dashboard.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: DashboardPage,
});

function DashboardPage() {
  const { user, isLoading } = useAuth();
  const navigate = useNavigate();

  const roleQuery = useQuery({
    queryKey: ["user-role", user?.id],
    queryFn: () => fetchUserRole(user!.id),
    enabled: Boolean(user?.id),
  });

  useEffect(() => {
    if (!isLoading && !user) void navigate({ to: "/login", replace: true });
  }, [isLoading, user, navigate]);

  const role = roleQuery.data ?? null;

  useEffect(() => {
    if (!role) return;
    void navigate({ to: roleHome[role], replace: true });
  }, [role, navigate]);

  const noRole = Boolean(user) && roleQuery.isSuccess && role === null;

  return (
    <div className="mx-auto max-w-6xl px-4 py-20 sm:px-6 lg:px-8">
      <h1 className="font-display text-3xl font-semibold sm:text-4xl">Dashboard</h1>
      <p className="mt-4 text-base leading-relaxed text-muted-foreground">
        {isLoading || roleQuery.isLoading
          ? "Loading your session…"
          : roleQuery.error
            ? (roleQuery.error as Error).message
            : noRole
              ? "Your account does not have a portal role assigned yet. Please contact the school administration."
              : "Taking you to your dashboard…"}
      </p>
      <div className="mt-10 flex flex-wrap gap-3">
        <button
          type="button"
          onClick={async () => {
            await signOut();
            void navigate({ to: "/login", replace: true });
          }}
          className="inline-flex h-11 items-center justify-center rounded-md bg-amber px-5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-amber-soft"
        >
          Sign out
        </button>
        <Link
          to="/"
          className="inline-flex h-11 items-center justify-center rounded-md border border-border px-5 text-sm font-medium transition-colors hover:border-amber/70 hover:text-amber"
        >
          Back to site
        </Link>
      </div>
    </div>
  );
}
