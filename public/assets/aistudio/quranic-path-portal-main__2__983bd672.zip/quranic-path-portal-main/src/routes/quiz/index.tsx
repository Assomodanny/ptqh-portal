import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";

import {
  EmptyState,
  PortalShell,
  portalCard,
  portalGhostButton,
  portalPrimaryButton,
} from "@/components/portal-shell";
import { createSession, fetchQuizzes } from "@/lib/quiz";
import { usePortalRole } from "@/lib/use-portal-role";

export const Route = createFileRoute("/quiz/")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Live Quiz — Path to Qur'anic Understanding" },
      {
        name: "description",
        content: "Host a live quiz session for your class and follow the leaderboard in real time.",
      },
      { property: "og:title", content: "Live Quiz — Path to Qur'anic Understanding" },
      { property: "og:description", content: "Host a live quiz session for your class." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: QuizHostListPage,
});

function QuizHostListPage() {
  const { role, isLoading } = usePortalRole();
  const navigate = useNavigate();
  const [startingId, setStartingId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const quizzesQuery = useQuery({ queryKey: ["quizzes"], queryFn: fetchQuizzes });
  const canHost = role === "admin" || role === "teacher";

  async function handleStart(quizId: string) {
    setStartingId(quizId);
    setError(null);
    try {
      const session = await createSession(quizId);
      void navigate({ to: "/quiz/host/$sessionId", params: { sessionId: session.id } });
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setStartingId(null);
    }
  }

  return (
    <PortalShell
      eyebrow="Live quiz"
      title="Host a live quiz"
      subtitle="Start a session, share the 6-digit PIN with your students, then control the pace of the questions from here."
    >
      {isLoading || quizzesQuery.isLoading ? (
        <p className="text-sm text-muted-foreground">Loading quizzes…</p>
      ) : !canHost ? (
        <EmptyState
          title="Hosting is for teachers and administrators"
          body="Students join a live quiz with the PIN their teacher shares. Use the Join quiz page instead."
        />
      ) : quizzesQuery.error ? (
        <p className="rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive">
          {(quizzesQuery.error as Error).message}
        </p>
      ) : (quizzesQuery.data ?? []).length === 0 ? (
        <EmptyState
          title="No quizzes yet"
          body="Once quizzes and their questions are added to the school database, they will be listed here ready to host."
        />
      ) : (
        <div className="space-y-6">
          {error && (
            <p className="rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive">
              {error}
            </p>
          )}
          <ul className="grid gap-4 sm:grid-cols-2">
            {(quizzesQuery.data ?? []).map((quiz) => (
              <li key={quiz.id} className={portalCard}>
                <p className="text-xs uppercase tracking-[0.2em] text-amber">
                  {quiz.subject ?? "Subject pending"}
                </p>
                <h2 className="mt-3 font-display text-lg font-semibold text-headline">
                  {quiz.title ?? "Untitled quiz"}
                </h2>
                {quiz.description && (
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                    {quiz.description}
                  </p>
                )}
                <p className="mt-3 text-sm text-muted-foreground">
                  {quiz.questionCount} {quiz.questionCount === 1 ? "question" : "questions"}
                </p>
                <button
                  type="button"
                  disabled={startingId === quiz.id || quiz.questionCount === 0}
                  onClick={() => void handleStart(quiz.id)}
                  className={`${portalPrimaryButton} mt-5 disabled:cursor-not-allowed disabled:opacity-50`}
                >
                  {startingId === quiz.id ? "Creating session…" : "Start live session"}
                </button>
              </li>
            ))}
          </ul>
          <Link to="/quiz/join" className={portalGhostButton}>
            Open the student join page
          </Link>
        </div>
      )}
    </PortalShell>
  );
}
