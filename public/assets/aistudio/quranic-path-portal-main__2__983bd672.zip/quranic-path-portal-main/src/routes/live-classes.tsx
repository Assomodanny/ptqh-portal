import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import { EmptyState, portalCard, portalPrimaryButton } from "@/components/portal-shell";
import { useAuth } from "@/lib/auth";
import {
  createLiveClass,
  deleteLiveClass,
  fetchLiveClasses,
  fetchUserRole,
  formatDay,
  formatPlatform,
  formatTimeRange,
  type LiveClassInput,
} from "@/lib/portal";

export const Route = createFileRoute("/live-classes")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Live Classes — Path to Qur'anic Understanding" },
      {
        name: "description",
        content:
          "The recurring live class timetable for Path to Qur'anic Understanding, with join links for each session.",
      },
      { property: "og:title", content: "Live Classes — Path to Qur'anic Understanding" },
      {
        property: "og:description",
        content: "Day, time, subject and join link for every live session.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: LiveClassesPage,
});

const emptyForm: LiveClassInput = {
  subject: "",
  day_of_week: "",
  start_time: "",
  end_time: "",
  platform: "Google Meet",
  join_url: "",
};

function LiveClassesPage() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [form, setForm] = useState<LiveClassInput>(emptyForm);
  const [feedback, setFeedback] = useState<string | null>(null);

  const roleQuery = useQuery({
    queryKey: ["user-role", user?.id],
    queryFn: () => fetchUserRole(user!.id),
    enabled: Boolean(user?.id),
  });
  const isAdmin = roleQuery.data === "admin";

  const classesQuery = useQuery({ queryKey: ["live-classes"], queryFn: fetchLiveClasses });

  const addMutation = useMutation({
    mutationFn: (input: LiveClassInput) =>
      createLiveClass({
        subject: input.subject?.trim() || null,
        day_of_week: input.day_of_week?.trim() || null,
        start_time: input.start_time || null,
        end_time: input.end_time || null,
        platform: input.platform?.trim() || null,
        join_url: input.join_url?.trim() || null,
      }),
    onSuccess: async () => {
      setForm(emptyForm);
      setFeedback("Class added.");
      await queryClient.invalidateQueries({ queryKey: ["live-classes"] });
    },
    onError: (error: Error) => setFeedback(error.message),
  });

  const removeMutation = useMutation({
    mutationFn: (id: string) => deleteLiveClass(id),
    onSuccess: async () => {
      setFeedback("Class removed.");
      await queryClient.invalidateQueries({ queryKey: ["live-classes"] });
    },
    onError: (error: Error) => setFeedback(error.message),
  });

  const classes = classesQuery.data ?? [];

  return (
    <div className="min-h-[calc(100vh-8rem)]">
      <div className="hero-gradient border-b border-border">
        <div className="mx-auto max-w-6xl px-4 py-14 sm:px-6 sm:py-16 lg:px-8">
          <p className="inline-flex items-center rounded-full border border-amber/40 bg-amber/10 px-4 py-1.5 text-xs font-medium uppercase tracking-[0.18em] text-amber">
            Timetable
          </p>
          <h1 className="mt-6 text-balance font-display text-3xl font-semibold tracking-tight sm:text-4xl">
            Live classes
          </h1>
          <p className="mt-4 max-w-2xl text-sm leading-relaxed text-foreground/85">
            Recurring live sessions with the day, time, subject and platform. Join links open in a
            new tab — sessions are held on Google Meet or WhatsApp.
          </p>
        </div>
      </div>

      <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6 sm:py-16 lg:px-8">
        {classesQuery.isLoading ? (
          <p className="text-sm text-muted-foreground">Loading the timetable…</p>
        ) : classesQuery.error ? (
          <p className="rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive">
            {(classesQuery.error as Error).message}
          </p>
        ) : classes.length === 0 ? (
          <EmptyState
            title="No live classes scheduled"
            body="Once the school administration publishes the timetable, every session will appear here with its join link."
          />
        ) : (
          <ul className="grid gap-4 sm:grid-cols-2">
            {classes.map((item) => (
              <li key={item.id} className={portalCard}>
                <p className="text-xs uppercase tracking-[0.2em] text-amber">
                  {formatDay(item.day_of_week)}
                </p>
                <p className="mt-3 font-display text-lg font-semibold text-headline">
                  {item.subject ?? "Subject to be confirmed"}
                </p>
                <p className="mt-2 text-sm text-muted-foreground">
                  {formatTimeRange(item.start_time, item.end_time)}
                </p>
                <p className="mt-1 text-sm text-muted-foreground">
                  {formatPlatform(item.platform)}
                </p>
                <div className="mt-5 flex flex-wrap items-center gap-3">
                  {item.join_url ? (
                    <a
                      href={item.join_url}
                      target="_blank"
                      rel="noreferrer noopener"
                      className={portalPrimaryButton}
                    >
                      Join class
                    </a>
                  ) : (
                    <span className="text-sm text-muted-foreground">Join link pending</span>
                  )}
                  {isAdmin && (
                    <button
                      type="button"
                      onClick={() => removeMutation.mutate(item.id)}
                      className="text-sm text-muted-foreground underline underline-offset-4 hover:text-destructive"
                    >
                      Remove
                    </button>
                  )}
                </div>
              </li>
            ))}
          </ul>
        )}

        {isAdmin && (
          <section aria-labelledby="add-class" className="mt-14">
            <h2 id="add-class" className="font-display text-xl font-semibold">
              Add a live class
            </h2>
            <form
              className="mt-6 grid gap-4 sm:grid-cols-2"
              onSubmit={(event) => {
                event.preventDefault();
                setFeedback(null);
                addMutation.mutate(form);
              }}
            >
              {(
                [
                  { key: "subject", label: "Subject", type: "text" },
                  { key: "day_of_week", label: "Day of week", type: "text" },
                  { key: "start_time", label: "Start time", type: "time" },
                  { key: "end_time", label: "End time", type: "time" },
                  { key: "platform", label: "Platform", type: "text" },
                  { key: "join_url", label: "Join link", type: "url" },
                ] as const
              ).map((field) => (
                <label key={field.key} className="block text-sm">
                  <span className="text-xs uppercase tracking-[0.18em] text-muted-foreground">
                    {field.label}
                  </span>
                  <input
                    type={field.type}
                    value={form[field.key] ?? ""}
                    onChange={(event) =>
                      setForm((prev) => ({ ...prev, [field.key]: event.target.value }))
                    }
                    className="mt-2 h-11 w-full rounded-md border border-border bg-card/70 px-3 text-sm text-foreground outline-none transition-colors focus:border-amber"
                  />
                </label>
              ))}
              <div className="sm:col-span-2">
                <button
                  type="submit"
                  disabled={addMutation.isPending}
                  className={portalPrimaryButton}
                >
                  {addMutation.isPending ? "Saving…" : "Add class"}
                </button>
              </div>
            </form>
          </section>
        )}

        {feedback && <p className="mt-6 text-sm text-muted-foreground">{feedback}</p>}
      </div>
    </div>
  );
}
