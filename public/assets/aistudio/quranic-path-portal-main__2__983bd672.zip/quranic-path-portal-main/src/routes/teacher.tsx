import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";

import { EmptyState, PortalShell, portalCard } from "@/components/portal-shell";
import { fetchProfile, fetchTeacherByProfile } from "@/lib/portal";
import { usePortalRole } from "@/lib/use-portal-role";

export const Route = createFileRoute("/teacher")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Teacher Dashboard — Path to Qur'anic Understanding" },
      {
        name: "description",
        content: "Your teaching profile, subject assignments and live classes.",
      },
      { property: "og:title", content: "Teacher Dashboard — Path to Qur'anic Understanding" },
      { property: "og:description", content: "Your teaching profile and live classes." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: TeacherPage,
});

function TeacherPage() {
  const { user, role, isLoading } = usePortalRole("teacher");

  const profileQuery = useQuery({
    queryKey: ["profile", user?.id],
    queryFn: () => fetchProfile(user!.id),
    enabled: Boolean(user?.id),
  });

  const teacherQuery = useQuery({
    queryKey: ["teacher-row", user?.id],
    queryFn: () => fetchTeacherByProfile(user!.id),
    enabled: Boolean(user?.id) && role === "teacher",
  });

  const profile = profileQuery.data;
  const teacher = teacherQuery.data;

  return (
    <PortalShell
      eyebrow="Teaching staff"
      title={profile?.full_name ? `Welcome, ${profile.full_name}` : "Teacher dashboard"}
      subtitle={profile?.email ?? user?.email ?? undefined}
    >
      {isLoading || teacherQuery.isLoading ? (
        <p className="text-sm text-muted-foreground">Loading your details…</p>
      ) : (
        <div className="space-y-12">
          <section aria-labelledby="my-details">
            <h2 id="my-details" className="font-display text-xl font-semibold">
              My details
            </h2>
            {teacherQuery.error ? (
              <p className="mt-4 rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive">
                {(teacherQuery.error as Error).message}
              </p>
            ) : !teacher ? (
              <div className="mt-6">
                <EmptyState
                  title="No teacher record found"
                  body="Your account is not yet linked to a teaching record. Please contact the school administration."
                />
              </div>
            ) : (
              <dl className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                {[
                  { label: "Employee ID", value: teacher.employee_id },
                  { label: "Specialisation", value: teacher.specialization },
                  { label: "Qualification", value: teacher.qualification },
                  { label: "Status", value: teacher.status },
                ].map((item) => (
                  <div key={item.label} className={portalCard}>
                    <dt className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
                      {item.label}
                    </dt>
                    <dd className="mt-3 text-base text-headline">{item.value ?? "Not recorded"}</dd>
                  </div>
                ))}
              </dl>
            )}
          </section>

          <section aria-labelledby="assignments">
            <h2 id="assignments" className="font-display text-xl font-semibold">
              Subjects &amp; classes
            </h2>
            <div className="mt-6">
              <EmptyState
                title="Not yet assigned"
                body="Teacher-to-subject assignments are not tracked in the school database yet. Once the administration records them, your subjects and classes will be listed here."
              />
            </div>
          </section>

          <section aria-labelledby="live">
            <h2 id="live" className="font-display text-xl font-semibold">
              Live classes
            </h2>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
              The recurring live class timetable, with join links for Google Meet and WhatsApp.
            </p>
            <Link
              to="/quiz"
              className="mt-4 mr-4 inline-block text-sm font-semibold text-amber underline underline-offset-4"
            >
              Host a live quiz →
            </Link>
            <Link
              to="/live-classes"
              className="mt-4 inline-block text-sm font-semibold text-amber underline underline-offset-4"
            >
              View live classes →
            </Link>
          </section>
        </div>
      )}
    </PortalShell>
  );
}
