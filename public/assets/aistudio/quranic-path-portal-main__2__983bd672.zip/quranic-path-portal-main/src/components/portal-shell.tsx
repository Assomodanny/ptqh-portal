import type { ReactNode } from "react";
import { Link, useNavigate } from "@tanstack/react-router";

import { signOut } from "@/lib/auth";

export const portalCard =
  "rounded-xl border border-border bg-card/80 p-6 backdrop-blur-sm transition-colors duration-200 hover:border-amber/50";
export const portalPrimaryButton =
  "inline-flex h-11 items-center justify-center rounded-md bg-amber px-5 text-sm font-semibold tracking-wide text-primary-foreground transition-colors duration-200 hover:bg-amber-soft";
export const portalGhostButton =
  "inline-flex h-11 items-center justify-center rounded-md border border-amber/50 px-5 text-sm font-medium text-amber transition-colors duration-200 hover:border-amber hover:bg-amber/10";

export function SignOutButton() {
  const navigate = useNavigate();
  return (
    <button
      type="button"
      onClick={async () => {
        await signOut();
        void navigate({ to: "/login", replace: true });
      }}
      className="inline-flex h-11 items-center justify-center rounded-md border border-border px-5 text-sm font-medium text-muted-foreground transition-colors duration-200 hover:border-amber/70 hover:text-amber"
    >
      Sign out
    </button>
  );
}

export function PortalShell({
  eyebrow,
  title,
  subtitle,
  showSignOut = true,
  children,
}: {
  eyebrow: string;
  title: string;
  subtitle?: string | undefined;
  showSignOut?: boolean | undefined;
  children: ReactNode;
}) {

  return (
    <div className="min-h-[calc(100vh-8rem)]">
      <div className="hero-gradient border-b border-border">
        <div className="mx-auto max-w-6xl px-4 py-14 sm:px-6 sm:py-16 lg:px-8">
          <p className="inline-flex items-center rounded-full border border-amber/40 bg-amber/10 px-4 py-1.5 text-xs font-medium uppercase tracking-[0.18em] text-amber">
            {eyebrow}
          </p>
          <h1 className="mt-6 text-balance font-display text-3xl font-semibold tracking-tight sm:text-4xl">
            {title}
          </h1>
          {subtitle && (
            <p className="mt-4 max-w-2xl text-sm leading-relaxed text-foreground/85">{subtitle}</p>
          )}
          <div className="mt-8 flex flex-wrap gap-3">
            <Link to="/live-classes" className={portalGhostButton}>
              Live classes
            </Link>
            {showSignOut && <SignOutButton />}
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6 sm:py-16 lg:px-8">{children}</div>
    </div>
  );
}

export function EmptyState({ title, body }: { title: string; body: string }) {
  return (
    <div className="rounded-xl border border-dashed border-border bg-card/50 p-8 text-center">
      <p className="font-display text-lg font-semibold text-headline">{title}</p>
      <p className="mx-auto mt-2 max-w-md text-sm leading-relaxed text-muted-foreground">{body}</p>
    </div>
  );
}
