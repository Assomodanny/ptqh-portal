import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { Menu, X } from "lucide-react";


const navLinks = [
  { label: "Curriculum", href: "/#curriculum" },
  { label: "Live classes", href: "/live-classes" },
  { label: "About", href: "/#about" },
  { label: "FAQ", href: "/#faq" },
  { label: "Contact", href: "/#contact" },
];

export function SiteHeader() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 w-full border-b border-border bg-background/85 backdrop-blur-md">
      <div className="mx-auto grid max-w-6xl grid-cols-[minmax(0,1fr)_auto] items-center gap-4 px-4 py-4 sm:px-6 lg:px-8">
        <Link
          to="/"
          className="flex min-w-0 flex-col rounded-sm leading-tight transition-opacity hover:opacity-80"
          onClick={() => setIsOpen(false)}
        >
          <span className="font-display text-lg font-semibold tracking-tight text-amber sm:text-xl lg:text-[1.6rem]">
            <span className="sm:hidden">PTQU</span>
            <span className="hidden sm:inline">Path to Qur'anic Understanding</span>
          </span>
          <span className="mt-1 h-px w-full max-w-[13rem] bg-amber/45" aria-hidden="true" />
          <span className="mt-1.5 text-[11px] uppercase tracking-[0.24em] text-muted-foreground sm:text-xs">
            School Portal
          </span>
        </Link>



        <div className="flex items-center gap-2 sm:gap-6">
          <nav aria-label="Primary" className="hidden md:block">
            <ul className="flex items-center gap-6">
              {navLinks.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    className="border-b border-transparent pb-1 text-sm text-muted-foreground transition-colors duration-200 hover:border-amber hover:text-headline"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          <Link
            to="/quiz/join"
            className="hidden text-sm text-muted-foreground transition-colors duration-200 hover:text-headline md:inline-block"
          >
            Join quiz
          </Link>

          <Link
            to="/login"
            className="hidden h-10 shrink-0 items-center justify-center rounded-md bg-amber px-5 text-sm font-semibold tracking-wide text-primary-foreground transition-colors duration-200 hover:bg-amber-soft sm:inline-flex"
          >
            Sign in
          </Link>

          <button
            type="button"
            aria-label={isOpen ? "Close menu" : "Open menu"}
            aria-expanded={isOpen}
            aria-controls="mobile-nav"
            onClick={() => setIsOpen((v) => !v)}
            className="grid size-11 shrink-0 place-items-center rounded-md border border-border text-foreground transition-colors duration-200 hover:border-amber/70 hover:text-amber md:hidden"
          >
            {isOpen ? (
              <X className="size-5" aria-hidden="true" />
            ) : (
              <Menu className="size-5" aria-hidden="true" />
            )}
          </button>
        </div>
      </div>

      {isOpen && (
        <nav
          id="mobile-nav"
          aria-label="Mobile"
          className="border-t border-border bg-background md:hidden"
        >
          <ul className="mx-auto max-w-6xl px-4 py-3 sm:px-6">
            {navLinks.map((link) => (
              <li key={link.href}>
                <a
                  href={link.href}
                  onClick={() => setIsOpen(false)}
                  className="block border-b border-border/60 py-4 text-base text-foreground transition-colors duration-200 hover:text-amber"
                >
                  {link.label}
                </a>
              </li>
            ))}
            <li>
              <Link
                to="/quiz/join"
                onClick={() => setIsOpen(false)}
                className="block border-b border-border/60 py-4 text-base text-foreground transition-colors duration-200 hover:text-amber"
              >
                Join quiz
              </Link>
            </li>
            <li className="pt-4 sm:hidden">
              <Link
                to="/login"
                onClick={() => setIsOpen(false)}
                className="inline-flex h-11 w-full items-center justify-center rounded-md bg-amber px-5 text-sm font-semibold text-primary-foreground transition-colors duration-200 hover:bg-amber-soft"
              >
                Sign in
              </Link>
            </li>
          </ul>
        </nav>
      )}
    </header>
  );
}
