import type { QuizParticipant } from "@/lib/quiz";

export function QuizLeaderboard({
  participants,
  highlightId,
  emptyLabel = "No one has joined yet.",
}: {
  participants: QuizParticipant[];
  highlightId?: string | undefined;
  emptyLabel?: string;
}) {
  const ranked = [...participants].sort((a, b) => (b.score ?? 0) - (a.score ?? 0));

  if (ranked.length === 0) {
    return <p className="text-sm text-muted-foreground">{emptyLabel}</p>;
  }

  return (
    <ol className="divide-y divide-border overflow-hidden rounded-xl border border-border bg-card/70">
      {ranked.map((participant, index) => {
        const isMe = highlightId === participant.id;
        return (
          <li
            key={participant.id}
            className={`flex items-center gap-4 px-4 py-3 text-sm ${
              isMe ? "bg-amber/10" : ""
            }`}
          >
            <span className="w-6 shrink-0 font-display text-base text-amber">{index + 1}</span>
            <span className="min-w-0 flex-1 truncate text-headline">
              {participant.student_name ?? "Anonymous"}
              {isMe && <span className="ml-2 text-xs uppercase tracking-[0.2em] text-amber">You</span>}
            </span>
            <span className="shrink-0 font-display text-base text-headline">
              {participant.score ?? 0}
            </span>
          </li>
        );
      })}
    </ol>
  );
}
